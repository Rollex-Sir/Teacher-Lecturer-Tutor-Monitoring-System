
class Lecturer extends Teacher {
    private String Department;
    private int YearsOfExperience;
    private int gradedScore;
    private boolean hasGraded;

    Lecturer(int Teacher_Id, String Teacher_Name, String Address, String Working_Type, String Employment_Status, int Working_Hours, String Department, int YearsOfExperience) {
        super(Teacher_Id, Teacher_Name, Address, Working_Type, Employment_Status);
        super.setWorking_Hours(Working_Hours);
        this.Department = Department;
        this.YearsOfExperience = YearsOfExperience;
        this.gradedScore = 0;
        this.hasGraded = false;
    }

    // Accessor methods
    public String getDepartment() {
        return Department;
    }

    public int getYearsOfExperience() {
        return YearsOfExperience;
    }

    public int getGradedScore() {
        return gradedScore;
    }

    public boolean gethasGraded() {
        return hasGraded;
    }

    // Mutator method for gradedScore
    public void setGradedScore(int newGradedScore) {
        this.gradedScore = newGradedScore;
    }

    // Method to grade assignments
    public void gradeAssignment(int score, String Department, int YearsOfExperience) {
        if (!hasGraded && YearsOfExperience >= 5 && Department.equals(Department)) {
            gradedScore = score;
            if (score >= 70) {
                System.out.println("You have scored A.");
            } else if (score >= 60) {
                System.out.println("You have scored B.");
            } else if (score >= 50) {
                System.out.println("You have scored C.");
            } else if (score >= 40) {
                System.out.println("You have scored D.");
            } else {
                System.out.println("You have Fail.");
            }
            hasGraded = true;
        } else {
            System.out.println("Assignment not graded yet or conditions not met.");
        }
    }

    // Method to display details
    public void displayDetails() {
        // Call the display method of the superclass (Teacher class)
        super.displayDetails();
        // Display additional details specific to the Lecturer class
        System.out.println("Department: " + Department);
        System.out.println("Years of Experience: " + YearsOfExperience);
        // Check if assignments have been graded
        if (hasGraded) {
            System.out.println("Graded Score: " + gradedScore);
        } else {
            System.out.println("Graded Score: Not Graded yet!");
        }
    }

  
}
