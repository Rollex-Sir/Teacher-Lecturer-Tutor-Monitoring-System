public class Teacher
{
    //attribute created
    
    private int Teacher_Id;
    private String Teacher_Name;
    private String Address;
    private String Working_Type;
    private String Employment_Status;
    private int Working_Hours;
    //parameterized constructor
    Teacher(int Teacher_Id,String Teacher_Name,String Address,String Working_Type,String Employment_Status)
    {
    
    this.Teacher_Id=Teacher_Id;
    this.Teacher_Name=Teacher_Name;
    this.Address=Address;
    this.Working_Type=Working_Type;
    this.Employment_Status=Employment_Status;
    
    }
    //getter methods
    public int getTeacher_Id()
    {
        return Teacher_Id;
    }
    public String getTeacher_Name()
    {
        return Teacher_Name;
    }
    public String getAddress()
    {
        return Address;
    }
    public String getWorking_Type()
    {
        return Working_Type;
    }
    public String getEmployment_Status()
    {
        return Employment_Status;
    }
    public int getWorking_Hours()
    {
        return Working_Hours;
    }
    //setter methods
    public void setWorking_Hours(int newWorking_Hours)
    {
        this.Working_Hours=newWorking_Hours;
    }
    //display methods
    public void displayDetails()
    {
        
        System.out.println("Teacher ID="+this.Teacher_Id);
        System.out.println("Teacher name="+this.Teacher_Name);
        System.out.println("Address="+this.Address);
        System.out.println("Working type="+this.Working_Type);
        System.out.println("Employment Status="+this.Employment_Status);
        if(Working_Hours==0){
        System.out.println("Teacher hasn't assigned any work.");
        }
        else{
            System.out.println("Working_Hours "+Working_Hours );
        }
    }
    
    
}
