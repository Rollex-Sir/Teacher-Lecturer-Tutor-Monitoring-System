import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Teacher_GUI {
    ArrayList<Teacher> list= new ArrayList<>();
    private JFrame jf1,jf,jft;
    private JPanel jp1,p1;
    private JLabel h1,h3,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,h4,lb1,lb2,lb3,lb4,lb5,lb6,lb7,lb8,lb9,lb10,lb11,lb12,h5;
    private JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8,tf9,tf10,tf11,tf12;
    private JButton b1,b2,b11,b12,b3,b4,b5,b6,jb1,jb2,jb3,jb4,jb5,jb6,jb7;
    public void t1() 
    {
        JFrame jf1 = new JFrame("GUI");
        
        jf1.setDefaultCloseOperation(jf1.EXIT_ON_CLOSE);
        
        jf1.setSize(1500, 800);
        jf1.setResizable(false);
        jf1.setLayout(null);
        
        //Creating main Panel
        JPanel jp1 = new JPanel();
        jp1.setLayout(null);
        jp1.setBounds(0,0,1500,800);
        jp1.setBackground(new Color(204,255,255));
        jf1.add(jp1);
        
        JLabel h1 = new JLabel("Teacher GUI");
        h1.setBounds(600, 50, 250, 30);
        Font headingFont = new Font("Algerian", Font.BOLD, 35);
        h1.setFont(headingFont);
        h1.setForeground(Color.BLACK);
        jp1.add(h1);
        
        JLabel h2 = new JLabel("Copyright © 2024 Hirdesh");
        h2.setBounds(1000, 700, 400, 50);
        Font headingFont00 = new Font("Monospaced", Font.BOLD, 25);
        h2.setFont(headingFont00);
        h2.setForeground(Color.BLACK);
        jp1.add(h2);
        
        //creating a panel
        JPanel p1 = new JPanel();
        p1.setBounds(325,150,800,500);
        p1.setBackground(Color.WHITE);
        p1.setLayout(null);
        jp1.add(p1);
        
        //making the object of color to call the Lecturer and Tutor buttons
        //with the help of obj replacing color code
        Color c1 = new Color (204,255,255);

        JButton b2 = new JButton("Lecturer");
        b2.setBounds(50, 220, 300, 68);
        Font headingFont2 = new Font("Monospaced", Font.BOLD, 45);
        b2.setFont(headingFont2);
        b2.setBackground(c1);
        p1.add(b2);
        b2.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                jf1.dispose();
                openNewGUI();
            }
        });
        
        
        JButton b1 = new JButton("Tutor");
        b1.setBounds(450, 220, 300, 68);
        Font headingFont3 = new Font("Monospaced", Font.BOLD, 45);
        b1.setFont(headingFont3);
        b1.setBackground(c1);
        b1.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                jf1.dispose();
                TutorGUI();
            }
        });
        p1.add(b1);
        
        
        jf1.setVisible(true);
    }
    private void openNewGUI()
    {
        JFrame jf = new JFrame("GUI");
        jf.setSize(1500, 800);
        jf.setResizable(false);
        jf.setLayout(null);
        
        JLabel h3 = new JLabel("Adding to Lecturer");
        h3.setBounds(640, 20, 700, 100);
        Font SemiheadingFont2 = new Font("Algerian", Font.BOLD, 35);
        h3.setFont(SemiheadingFont2);
        h3.setForeground(new Color(30, 64, 175));
        jf.add(h3);
        
        // Creating Jlabel and Jtextfield for Teacher ID
        JLabel l1 = new JLabel("Teacher ID");
        l1.setBounds(200, 160, 200, 20);
        Font SemiheadingFont3 = new Font("Monospaced", Font.BOLD, 20);
        l1.setFont(SemiheadingFont3);
        jf.add(l1);

        JTextField t1 = new JTextField();
        t1.setBounds(450, 160, 200, 20);
        jf.add(t1);
        
        
        // Creating Jlabel and Jtextfield for Teacher Name
        JLabel l2 = new JLabel("Teacher Name");
        l2.setBounds(200, 200, 200, 20);
        Font SemiheadingFont4 = new Font("Monospaced", Font.BOLD, 20);
        l2.setFont(SemiheadingFont4);
        jf.add(l2);

        JTextField t2 = new JTextField();
        t2.setBounds(450, 200, 200, 20);
        jf.add(t2);
        
        //// Creating Jlabel and Jtextfield for Address
        JLabel l3 = new JLabel("Address");
        l3.setBounds(200, 240, 200, 25);// Adjusted Y-coordinate
        Font SemiheadingFont5 = new Font("Monospaced", Font.BOLD, 20);
        l3.setFont(SemiheadingFont5);
        jf.add(l3);

        JTextField t3 = new JTextField();
        t3.setBounds(450, 240, 200, 20);
        jf.add(t3);
        
        // Creating Jlabel and Jtextfield for Department
        JLabel l4 = new JLabel("Department");
        l4.setBounds(800, 160, 200, 25);// Adjusted Y-coordinate
        Font SemiheadingFont6 = new Font("Monospaced", Font.BOLD, 20);
        l4.setFont(SemiheadingFont6);
        jf.add(l4);

        JTextField t4 = new JTextField();
        t4.setBounds(1050, 160, 200, 20);
        jf.add(t4);
        
        // Creating Jlabel and Jtextfield for Employement Status
        JLabel l5 = new JLabel("Employment Status");
        l5.setBounds(800, 200, 300, 25);// Adjusted Y-coordinate
        Font SemiheadingFont7 = new Font("Monospaced", Font.BOLD, 20);
        l5.setFont(SemiheadingFont7);
        jf.add(l5);

        JTextField t5 = new JTextField();
        t5.setBounds(1050, 200, 200, 20);
        jf.add(t5);
        
        // Creating Jlabel and Jtextfield for Working Type
        JLabel l6 = new JLabel("Working Type");
        l6.setBounds(800, 240, 200, 25);// Adjusted Y-coordinate
        Font SemiheadingFont8 = new Font("Monospaced", Font.BOLD, 20);
        l6.setFont(SemiheadingFont8);
        jf.add(l6);

        JTextField t6 = new JTextField();
        t6.setBounds(1050, 240, 200, 20);
        jf.add(t6);
        
        // Creating Jlabel and Jtextfield for Year of Experience
        JLabel l7 = new JLabel("Year of Experience");
        l7.setBounds(200, 280, 300, 25);
        Font SemiheadingFont9 = new Font("Monospaced", Font.BOLD, 20);
        l7.setFont(SemiheadingFont9);
        jf.add(l7);
        
        JTextField t7 = new JTextField();
        t7.setBounds(450, 280, 200, 20);
        jf.add(t7);
        
        // Creating Jlabel and Jtextfield for Working Hours
        JLabel l11 = new JLabel("Working Hours");
        l11.setBounds(800, 280, 300, 25);
        Font SemiheadingFont17 = new Font("Monospaced", Font.BOLD, 20);
        l11.setFont(SemiheadingFont17);
        jf.add(l11);

        JTextField t11 = new JTextField();
        t11.setBounds(1050, 280, 200, 20);
        jf.add(t11);
        

        
        // Creating Jlabel as heading of Grade Assingments
        JLabel h4 = new JLabel("Grade Assingments");
        h4.setBounds(640, 350, 700, 100);
        Font SemiheadingFont13 = new Font("Algerian", Font.BOLD, 35);
        h4.setFont(SemiheadingFont13);
        h4.setForeground(new Color(30, 64, 175));
        jf.add(h4);
        
        // Creating Jlabel for Year of Experience
        JLabel l8 = new JLabel("Year of Experience");
        l8.setBounds(200, 450, 300, 25);
        Font SemiheadingFont14 = new Font("Monospaced", Font.BOLD, 20);
        l8.setFont(SemiheadingFont14);
        jf.add(l8);

        JTextField t8 = new JTextField();
        t8.setBounds(450, 450, 200, 20);
        jf.add(t8);
        
        // Creating Jlabel and Jtextfield for Score
        JLabel l9 = new JLabel("Score");
        l9.setBounds(200, 490, 300, 20);
        Font SemiheadingFont15 = new Font("Monospaced", Font.BOLD, 20);
        l9.setFont(SemiheadingFont15);
        jf.add(l9);

        JTextField t9 = new JTextField();
        t9.setBounds(450, 490, 200, 20);
        jf.add(t9);
        
        // Creating Jlabel and Jtextfield for Department
        JLabel l10 = new JLabel("Department");
        l10.setBounds(200, 530, 300, 25);
        Font SemiheadingFont16 = new Font("Monospaced", Font.BOLD, 20);
        l10.setFont(SemiheadingFont16);
        jf.add(l10);

        JTextField t10 = new JTextField();
        t10.setBounds(450, 530, 200, 20);
        jf.add(t10);
        
        //// Creating JButton for different requir
        JButton b11 = new JButton("Add Lecturer");
        b11.setBounds(200, 320, 150, 40);
        jf.add(b11);
        
        b11.addActionListener(new ActionListener()
    {
        public void actionPerformed(ActionEvent ae)
        {
            try{
                    int Teacher_Id = Integer.parseInt(t1.getText());
                    String Teacher_Name = t2.getText();
                    String Address = t3.getText();
                    String Department = t4.getText();
                    String Working_Type = t6.getText();
                    String Employment_Status = t5.getText();
                    int Working_Hours = Integer.parseInt(t11.getText());
                    int YearsOfExperience = Integer.parseInt(t7.getText());
                    
                    boolean exists = false;
            for (Teacher l1 : list) {
                if (l1 instanceof Lecturer && l1.getTeacher_Id() == Teacher_Id) {
                    exists = true;
                    break;
                }
            }

            if (exists) {
                JOptionPane.showMessageDialog(null, "This ID " + Teacher_Id + " already exists!");
            } else {
                // Create a Tutor object and add to the ArrayList if the ID is not found
                Lecturer l1 = new Lecturer( Teacher_Id, Teacher_Name,  Address,  Working_Type, Employment_Status,Working_Hours,Department,YearsOfExperience);
                    list.add(l1);
                    JOptionPane.showMessageDialog(null,"Addition Completed!!!");
            }
                    
                    
                    
                    
            } catch (NumberFormatException e)
            {
                    JOptionPane.showMessageDialog(null,"Wrong Input! Kindly fill the text field with correct value.");
            }
            }
            
        });
        
        JButton b12 = new JButton("Grade Assingments");
        b12.setBounds(400, 700, 150, 40);
        jf.add(b12);
        b12.addActionListener(new ActionListener()
    {
    public void actionPerformed(ActionEvent ae)
    {
        try{
            int score = Integer.parseInt(t9.getText());
            String Department = t10.getText(); // Corrected here
            int YearsOfExperience = Integer.parseInt(t8.getText());
            for(Teacher t: list){
                //downcasting 
                if(t instanceof Lecturer){
                    Lecturer L1 = (Lecturer) t;
                    L1.gradeAssignment(score,  Department,YearsOfExperience);
                }
            }
            JOptionPane.showMessageDialog(null,"Regards Effective! Graded Score Success.");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Please Give Accurate Details!");
        }
    }
    });
        
        JButton b3 = new JButton("Display");
        b3.setBounds(700, 700, 150, 40);
        jf.add(b3);
        b3.addActionListener(new ActionListener()
    {
    public void actionPerformed(ActionEvent ae)
    {
        try{
            for (Teacher t : list)
        {
             if (t instanceof Lecturer)
                    {
                        
                        t.displayDetails();
                        JOptionPane.showMessageDialog(null,"Your data has been displyed to BlueJ terminal!");
                    }
        }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"First fill the Text fields!");
        }
        
    }
    });
        JButton b4 = new JButton("Clear");
        b4.setBounds(1000, 700, 150, 40);
        jf.add(b4);
        
        b4.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae)
            {
            t1.setText("");
            t2.setText("");
            t3.setText("");
            t4.setText("");
            t5.setText("");
            t6.setText("");
            t7.setText("");
            t11.setText("");
            t8.setText("");
            t9.setText("");
            t10.setText("");
            JOptionPane.showMessageDialog(null,"Text Fields has been Cleared!");
            
            }
        });
        
        JButton b5 = new JButton("Change to Tutor ");
        b5.setBounds(1300, 700, 150, 40);
        b5.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                jf.dispose();
                TutorGUI();
            }
            
        });
        
        jf.add(b5);
        
        JButton b6 = new JButton ("Home");
        b6.setBounds(100,700,150,40);
        b6.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                jf.dispose();
                t1();
            }
            
        });
        jf.add(b6);
        
        jf.setVisible(true);
        
        JPanel panel1 = new JPanel();
        panel1.setBounds(0, 0, 1500, 800);
        panel1.setBackground(new Color(204,255,255));
        jf.add(panel1);
    }
    private void TutorGUI()
    {
        JFrame jft = new JFrame("GUI");
        jft.setSize(1500, 800);
        jft.setLayout(null);
        jft.setResizable(false);
        
        JLabel h3 = new JLabel("Adding to Tutor");
        h3.setBounds(640, 20, 700, 100);
        Font SemiheadingFont2 = new Font("Algerian", Font.BOLD, 35);
        h3.setFont(SemiheadingFont2);
        h3.setForeground(new Color(30, 64, 175));
        jft.add(h3);
        
        //Department with obj l6 and t6
        JLabel lb1 = new JLabel("Teacher ID");
        lb1.setBounds(200, 160, 200, 20);
        Font SemiheadingFont3 = new Font("Monospaced", Font.BOLD, 20);
        lb1.setFont(SemiheadingFont3);
        jft.add(lb1);

        JTextField tf1 = new JTextField();
        tf1.setBounds(450, 160, 200, 20);
        jft.add(tf1);
        //Years of exp with obj l7 and t7
        JLabel lb2 = new JLabel("Teacher Name");
        lb2.setBounds(200, 200, 200, 20);
        Font SemiheadingFont4 = new Font("Monospaced", Font.BOLD, 20);
        lb2.setFont(SemiheadingFont4);
        jft.add(lb2);

        JTextField tf2 = new JTextField();
        tf2.setBounds(450, 200, 200, 20);
        jft.add(tf2);
        
        //Working Hours with obj l8 and t8
        JLabel lb3 = new JLabel("Address");
        lb3.setBounds(200, 240, 200, 25);// Adjusted Y-coordinate
        Font SemiheadingFont5 = new Font("Monospaced", Font.BOLD, 20);
        lb3.setFont(SemiheadingFont5);
        jft.add(lb3);

        JTextField tf3 = new JTextField();
        tf3.setBounds(450, 240, 200, 20);
        jft.add(tf3);
        
        
        JLabel lb4 = new JLabel("Working Hours");
        lb4.setBounds(800, 160, 200, 25);// Adjusted Y-coordinate
        Font SemiheadingFont6 = new Font("Monospaced", Font.BOLD, 20);
        lb4.setFont(SemiheadingFont6);
        jft.add(lb4);

        JTextField tf4 = new JTextField();
        tf4.setBounds(1050, 160, 200, 20);
        jft.add(tf4);
        
        JLabel lb5 = new JLabel("Employment Status");
        lb5.setBounds(800, 200, 300, 25);// Adjusted Y-coordinate
        Font SemiheadingFont7 = new Font("Monospaced", Font.BOLD, 20);
        lb5.setFont(SemiheadingFont7);
        jft.add(lb5);

        JTextField tf5 = new JTextField();
        tf5.setBounds(1050, 200, 200, 20);
        jft.add(tf5);
        
        JLabel lb6 = new JLabel("Working Type");
        lb6.setBounds(800, 240, 200, 25);// Adjusted Y-coordinate
        Font SemiheadingFont8 = new Font("Monospaced", Font.BOLD, 20);
        lb6.setFont(SemiheadingFont8);
        jft.add(lb6);

        JTextField tf6 = new JTextField();
        tf6.setBounds(1050, 240, 200, 20);
        jft.add(tf6);
        
        JLabel lb7 = new JLabel("Specialization");
        lb7.setBounds(200, 280, 200, 20);
        Font SemiheadingFont9 = new Font("Monospaced", Font.BOLD, 20);
        lb7.setFont(SemiheadingFont9);
        jft.add(lb7);

        JTextField tf7 = new JTextField();
        tf7.setBounds(450, 280, 200, 20);
        jft.add(tf7);
        
        JLabel lb8 = new JLabel("Qualification");
        lb8.setBounds(800, 280, 200, 25);// Adjusted Y-coordinate
        Font SemiheadingFont10 = new Font("Monospaced", Font.BOLD, 20);
        lb8.setFont(SemiheadingFont10);
        jft.add(lb8);

        JTextField tf8 = new JTextField();
        tf8.setBounds(1050, 280, 200, 20);
        jft.add(tf8);
        
        JLabel lb9 = new JLabel("Performance Index");
        lb9.setBounds(200, 320, 300, 20);
        Font SemiheadingFont11 = new Font("Monospaced", Font.BOLD, 20);
        lb9.setFont(SemiheadingFont11);
        jft.add(lb9);

        JTextField tf9 = new JTextField();
        tf9.setBounds(450, 320, 200, 20);
        jft.add(tf9);
        
        JLabel lb10 = new JLabel("Salary");
        lb10.setBounds(800, 320, 200, 25);// Adjusted Y-coordinate
        Font SemiheadingFont12 = new Font("Monospaced", Font.BOLD, 20);
        lb10.setFont(SemiheadingFont12);
        jft.add(lb10);

        JTextField tf10 = new JTextField();
        tf10.setBounds(1050, 320, 200, 20);
        jft.add(tf10);
        
        JLabel h5 = new JLabel("Salary And Certification");
        h5.setBounds(550, 380, 700, 100);
        Font SemiheadingFont13 = new Font("Algerian", Font.BOLD, 35);
        h5.setFont(SemiheadingFont13);
        h5.setForeground(new Color(30, 64, 175));
        jft.add(h5);
        
        
        JLabel lb11 = new JLabel("New Preformance Index");
        lb11.setBounds(200, 475, 300, 25);
        Font SemiheadingFont14 = new Font("Monospaced", Font.BOLD, 20);
        lb11.setFont(SemiheadingFont14);
        jft.add(lb11);

        JTextField tf11 = new JTextField();
        tf11.setBounds(500, 475, 200, 20);
        jft.add(tf11);
        
        JLabel lb12 = new JLabel("New Salary");
        lb12.setBounds(200, 515, 300, 25);
        Font SemiheadingFont15 = new Font("Monospaced", Font.BOLD, 20);
        lb12.setFont(SemiheadingFont15);
        jft.add(lb12);

        JTextField tf12 = new JTextField();
        tf12.setBounds(500, 515, 200, 20);
        jft.add(tf12);
        
        JButton jb1 = new JButton("Add Tutor");
        jb1.setBounds(200, 360, 150, 40);
        jft.add(jb1);
        
          jb1.addActionListener(new ActionListener()
    {
        public void actionPerformed(ActionEvent ae)
        {
            try{
                    int teacherId = Integer.parseInt(tf1.getText());
                    String teacherName = tf2.getText();
                    String address = tf3.getText();
                    int performanceIndex= Integer.parseInt(tf9.getText());
                    int workingHours = Integer.parseInt(tf4.getText());
                    String employmentStatus = tf5.getText();
                    String workingType = tf6.getText();
                    String specialization = tf7.getText();
                    int salary = Integer.parseInt(tf10.getText());
                    String academicQualification  = tf8.getText();
                    
                    boolean exists = false;
            for (Teacher l1 : list) {
                if (l1 instanceof Tutor && l1.getTeacher_Id() == teacherId) {
                    exists = true;
                    break;
                }
            }

            if (exists) {
                JOptionPane.showMessageDialog(null, "   Tutor with ID " + teacherId + " already exists!");
            } else {
                // Creating a tutor object that will check if teacher id is exists already or not. If not then this will show message dialog box.
                Tutor T1 = new Tutor(teacherId,teacherName,address,workingType,employmentStatus,workingHours,salary,specialization,academicQualification,performanceIndex);
                    list.add(T1);
                    JOptionPane.showMessageDialog(null, "Many thanks! Successful Addition of Tutor");
            }
                    
                    
                    
                    
            } catch (NumberFormatException e)
            {
                    JOptionPane.showMessageDialog(null,"Kindly complete the entire text field.");
            }
            }
            
        });
    
        
        
        JButton jb2 = new JButton("Set Salary");
        jb2.setBounds(400, 700, 150, 40);
        jft.add(jb2);
        
        
        
        jb2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                for (Teacher t : list){
                try {
                    int newSalary = Integer.parseInt(tf12.getText());
                    int newPerformanceIndex = Integer.parseInt(tf11.getText());
                    Tutor T1 = (Tutor) t;
                    T1.setSalaryAndCertification(newSalary,newPerformanceIndex);
                    JOptionPane.showMessageDialog(null, "Many thanks! Salary Successfully set.");
                    }
                    catch(Exception e){
                    JOptionPane.showMessageDialog(null, "Re-enter Correct Information to Set Salary");
                
                    }
            }
        }
        });
        
        JButton jb3 = new JButton("Display");
        jb3.setBounds(700, 700, 150, 40);
        jft.add(jb3);
        
        jb3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                try{
                    for (Teacher t : list)
                {
                    if(t instanceof Tutor )
                    {
                        t.displayDetails();
                        JOptionPane.showMessageDialog(null,"Your data has been displyed to BlueJ terminal!");
                    }
                }
                }catch(Exception e){
                    JOptionPane.showMessageDialog(null,"First fill the text fields to display the information!");
                }
                
            }
        });
        
        
        JButton jb4 = new JButton("Clear");
        jb4.setBounds(1000, 700, 150, 40);
        jft.add(jb4);
        
        jb4.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae)
            {
            tf1.setText("");
            tf2.setText("");
            tf3.setText("");
            tf4.setText("");
            tf5.setText("");
            tf6.setText("");
            tf7.setText("");
            tf11.setText("");
            tf8.setText("");
            tf9.setText("");
            tf10.setText("");
            tf12.setText("");
            JOptionPane.showMessageDialog(null,"Text Fields Has Been Cleared");
            }
        });
        
        JButton jb5 = new JButton("Change to Lecturer ");
        jb5.setBounds(1300, 700, 150, 40);
        jft.add(jb5);
        jb5.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                jft.dispose();
                openNewGUI();
            }
            
        });
        
        JButton jb6 = new JButton("Remove Tutor");
        jb6.setBounds(200, 575, 140, 40);
        jft.add(jb6);
        
        jb6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                
                    boolean tutorFound = false;
                    for (Teacher t : list)
                {
                    if(t instanceof Tutor )
                    {
                     Tutor T2 = (Tutor) t;
                     T2.removeTutor(); 
                     tutorFound = true;
                    }   
                    
                }
                if (tutorFound) {
                JOptionPane.showMessageDialog(null, "Tutor removed successfully!");
                tf9.setText("");
                tf7.setText("");
                tf10.setText("");
                tf8.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Without adding to Tutor, tutor can't be removed! ");
                }
                
                
        }
        });
        
        JButton jb7 = new JButton ("Home");
        jb7.setBounds(100,700,150,40);
        jb7.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                
                jft.dispose();
                t1();
            }
            
        });
        jft.add(jb7);
        
        
        
        
        
        jft.setVisible(true);
        
        JPanel panel1 = new JPanel();
        panel1.setBounds(0, 0, 1500, 800);
        panel1.setBackground(new Color(204,255,255));
        jft.add(panel1);

    }
    public static void main(String[]args)
    {
        
        Teacher_GUI p = new Teacher_GUI();
        p.t1();
    }
} 