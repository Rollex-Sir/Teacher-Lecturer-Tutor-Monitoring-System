public class Tutor extends Teacher {
    // Additional attributes
    private double Salary;
    private String Specialization;
    private String Academic_Qualifications;
    private int Performance_Index;
    private boolean isCertified;

    // Constructor
    public Tutor(int Teacher_Id, String Teacher_Name, String Address, String Working_Type, String Employment_Status,
                 int Working_Hours, double Salary, String Specialization, String Academic_Qualifications,
                 int Performance_Index) {
        super(Teacher_Id, Teacher_Name,Address, Working_Type, Employment_Status);
        this.setWorking_Hours(Working_Hours);
        this.Salary = Salary;
        this.Specialization = Specialization;
        this.Academic_Qualifications = Academic_Qualifications;
        this.Performance_Index = Performance_Index;
        this.isCertified = false;
    }

    // Accessor methods
    public double getSalary() {
        return Salary;
    }

    public String getSpecialization() {
        return Specialization;
    }

    public String getAcademicQualifications() {
        return Academic_Qualifications;
    }

    public int getPerformanceIndex() {
        return Performance_Index;
    }

    public boolean isCertified() {
        return isCertified;
    }

    // Method to set salary and certification status
    public void setSalaryAndCertification(double newSalary, int newPerformanceIndex)
    {
        
        if (newPerformanceIndex > 5 && getWorking_Hours() > 20) {
            double appraisalPercentage;
            Performance_Index = newPerformanceIndex;
            if (newPerformanceIndex >= 5 && newPerformanceIndex <= 7) {
                appraisalPercentage = 0.05;
            } else if (newPerformanceIndex >= 8 && newPerformanceIndex <= 9) {
                appraisalPercentage = 0.1;
            } else {
                appraisalPercentage = 0.2;
            }

            Salary = newSalary + (appraisalPercentage * newSalary);
            isCertified = true;
        } else {
            System.out.println("Salary cannot be approved. Tutor is not certified yet.");
        }
    }

    // Method to remove tutor
    public void removeTutor() {
        if (isCertified) {
            Salary = 0;
            Specialization = "";
            Academic_Qualifications = "";
            Performance_Index = 0;
            //isCertified = false;
        }
        else{
            System.out.println("Tutor can be removed");
        }
    }

    // Display method
    public void displayDetails() {
        super.displayDetails(); // Call the displayDetails method in the parent class

        if (isCertified) {
            System.out.println("Salary: " + Salary);
            System.out.println("Specialization: " + Specialization);
            System.out.println("Academic Qualifications: " + Academic_Qualifications);
            System.out.println("Performance Index: " + Performance_Index);
        }
        else{
            System.out.println("Tutor not certified");
        }
    }

   
}
